import random
import time
from tkinter import *
from PIL import Image, ImageTk


win = Tk()
win.title("Trillionaire Tycoon")
win.resizable(False, False)
win.attributes("-fullscreen", True)
money = 27000
products = 350
score = 0 
cost = 1000
number1 = 400
number2 = 410


screen_width = win.winfo_screenwidth()



if screen_width > 853:
  image1 = Image.open("Stock.png")
  image1 = image1.resize((863, 446), Image.ANTIALIAS)
  test = ImageTk.PhotoImage(image1)
  label90 = Label(win,image=test, bg = "grey")
  label90.image = test
  label90.pack()
else:
  image1 = Image.open("Stock.png")
  image1 = image1.resize((817, 446), Image.ANTIALIAS)
  test = ImageTk.PhotoImage(image1)
  label90 = Label(win,image=test, bg = "grey")
  label90.image = test
  label90.pack()



def destroy():
  CostL3.destroy()
  Quest3.destroy()
  Enter3.destroy()
  invest4.destroy()
  Quest4.destroy()
  invest5.destroy()
  invest6.destroy()
  Quest5.destroy()
  Quest6.destroy()
  Back3.destroy()
  Chs.destroy()
  pound.destroy()
  Products.destroy()
  next()
  pound.config(text = "Company Balance: £"+str(money),fg = "black")
  Products.config(text = "Products: "+str(products), fg = "black")





def element98():
  global money

  agent = random.randint(1,10)
  if agent < 8:
    money += 2000
    pound.config(text = "Company Balance: £"+str(money))
    time.sleep(0.3)

    invest6.config(state = DISABLED)
  else:
    invest6.config(state= DISABLED)
  if money < 10000:
    win.destroy()
    win4 = Tk()
    win4.title("Trillionaire tycoon")
    win4.attributes("-fullscreen", True)
    ag = Label(win4, text = "Unfortunately, you fell bellow the amount needed to sustain your business...\n Are you willing to try again??")
    ag.place(relx = 0.12, rely = 0.3)
    win4.mainloop()




  






def element48():
  global money
  global currently3
  agent = random.randint(1,10)
  if agent < 7:
    money += 2000
    pound.config(text = "Company Balance: £"+str(money))
    time.sleep(0.3)
    invest5.config(state = DISABLED)
  else:
    money -= 1000
    pound.config(text = "Company Balance: £"+str(money))
    invest5.config(state= DISABLED)
  if money < 10000:
    win.destroy()
    win4 = Tk()
    win4.title("Trillionaire tycoon")
    win4.attributes("-fullscreen", True)
    ag = Label(win4, text = "Unfortunately, you fell bellow the amount needed to sustain your business...\n Are you willing to try again??")
    ag.place(relx = 0.12, rely = 0.3)
    win4.mainloop()

 



def element23():
  global money
  global currently2
  agent = random.randint(1,10)
  
  if agent < 5:
    money += 2000
    pound.config(text = "Company Balance: £"+str(money))
    time.sleep(0.3)
    invest4.config(state = DISABLED)
  else:
    money -= 1000
    pound.config(text = "Company Balance: £"+str(money))
    invest4.config(state= DISABLED)
  if money < 10000:
    win.destroy()
    win4 = Tk()
    win4.title("Trillionaire tycoon")
    win4.attributes("-fullscreen", True)
    ag = Label(win4, text = "Unfortunately, you fell bellow the amount needed to sustain your business...\n Are you willing to try again??")
    ag.place(relx = 0.12, rely = 0.3)
    win4.mainloop()


  
 





def element():
  global money
  global currently
  agent = random.randint(1,10)
  if agent < 6:
    money += 2000
    pound.config(text = "Company Balance: £"+str(money))
    time.sleep(0.3)
 
    Enter3.config(state = DISABLED)
  else:
    Enter3.config(state= DISABLED)

  if money < 10000:
    win.destroy()
    win4 = Tk()
    win4.title("Trillionaire tycoon")
    win4.attributes("-fullscreen", True)
    ag = Label(win4, text = "Unfortunately, you fell bellow the amount needed to sustain your business...\n Are you willing to try again??")
    ag.place(relx = 0.12, rely = 0.3)
    win4.mainloop()
  

  





def invest():
  A.destroy()
  time.sleep(0.3)
  B.destroy()
  time.sleep(0.03)
  C.destroy()
  time.sleep(0.03)
  D.destroy()
  global CostL3
  global Quest3

  CostL3 = Label(win, text = "% => [Chance of return on investment] | [Investment: £1000 -> £2000 , 0 , -£1000", bg = "grey")
  CostL3.place(relx = 0.067, rely = 0.37)

  Quest3 = Label(win, text = "1. Bitcoin Stocks:(65%) + Insurance", bg="grey")
  Quest3.place(relx = 0.07, rely = 0.5)



  global Enter3
  Enter3 = Button(win, text = "Invest", fg = "#2b1d0e", bg = "#989898", activebackground = "#505050",command = element)
  Enter3.place(relx = 0.45, rely = 0.485, relheight = 0.08, relwidth = 0.12)
  global Quest4

  Quest4 = Label(win, text = "2. Gold Stocks:(90%), no Insurance", bg ="grey")
  Quest4.place(relx = 0.07, rely = 0.6)



  global invest4
  invest4 = Button(win, text = "Invest", fg = "#2b1d0e", bg = "#989898", activebackground = "#505050",command = element23)
  invest4.place(relx = 0.45, rely = 0.585, relheight = 0.08, relwidth = 0.12)


  global Quest5
  Quest5 = Label(win, text = "3. Apple Stocks:(80%), no Insurance", bg ="grey")
  Quest5.place(relx = 0.07, rely = 0.7)



  global invest5
  invest5 = Button(win, text = "Invest", fg = "#2b1d0e", bg = "#989898", activebackground = "#505050",command  = element48)
  invest5.place(relx = 0.45, rely = 0.685, relheight = 0.08, relwidth = 0.12)


  global Quest6
  Quest6 = Label(win, text = "4. Tesla Stocks:(70%) + Insurance",bg = "grey")
  Quest6.place(relx = 0.07, rely = 0.8)



  global invest6
  invest6 = Button(win, text = "Invest", fg = "#2b1d0e", bg = "#989898", activebackground = "#505050",command = element98)
  invest6.place(relx = 0.45, rely = 0.785, relheight = 0.08, relwidth = 0.12)








  
  global Back3
  global Chs


  Back3 = Button(win, text = "⇦", font = "Bold",fg = "#2b1d0e", bg = "#989898", activebackground = "#505050", command = destroy)
  Back3.place(relx = 0.07, rely = 0.26, relheight = 0.08, relwidth = 0.08)

  Chs.config(text = "[press to go back]", fg = "#2b1d0e")
  Chs.place(relx = 0.18, rely = 0.276)












def al():
  CostL2.destroy()
  Enter2.destroy()
  Back2.destroy()
  Chs.destroy()
  Quest2.destroy()
  tell.destroy()
  pound.destroy()
  Products.destroy()
  next()
  pound.config(text = "Company Balance: £"+str(money),fg = "black")
  Products.config(text = "Products: "+str(products), fg = "black")  





def spontan():
  global number1
  global number2
  global money
  number1 += 10
  number2 += 10

  money -= 400
  pound.config(text = "Company Balance: £"+str(money), fg = "black")





  if money < 10000:
    win.destroy()
    win4 = Tk()
    win4.title("Trillionaire tycoon")
    win4.attributes("-fullscreen", True)
    ag = Label(win4, text = "Unfortunately, you fell bellow the amount needed to sustain your business...\n Are you willing to try again??")
    ag.place(relx = 0.12, rely = 0.3)
    win4.mainloop()





def camp():
  A.destroy()
  time.sleep(0.3)
  B.destroy()
  time.sleep(0.03)
  C.destroy()
  time.sleep(0.03)
  D.destroy()

  global CostL2
  global Quest2

  CostL2 = Label(win, text = "The cost of marketing/campaigning is £400", bg = "grey")
  CostL2.place(relx = 0.06, rely = 0.40)

  Quest2 = Label(win, text = "Click Yes to proceed with payment: ", bg = "grey")
  Quest2.place(relx = 0.06, rely = 0.72)

  global tell
  tell = Label(win, text = "Clicking Yes => increase in market value e.g.  [100-110] => [110-120]", bg = "grey")
  tell.place(relx = 0.06, rely = 0.55)

 

  global Enter2
  Enter2 = Button(win, text = "Yes / ✓", fg = "green", bg = "#989898", activebackground = "#505050", command = spontan)
  Enter2.place(relx = 0.43, rely = 0.7, relheight = 0.085, relwidth = 0.12)
  global Back2
  global Chs


  Back2 = Button(win, text = "⇦", font = "Bold",fg = "green", bg = "#989898", activebackground = "#505050", command = al)
  Back2.place(relx = 0.06, rely = 0.26, relheight = 0.08, relwidth = 0.08)

  Chs.config(text = "[press to go back]", fg = "green")
  Chs.place(relx = 0.17, rely = 0.275)














def redot():
  CostL1.destroy()
  Enterz.destroy()
  e1.destroy()
  Backz.destroy()
  Chs.destroy()
  Quest1.destroy()
  omz.destroy()
  pound.destroy()
  Products.destroy()
  next()
  pound.config(text = "Company Balance: £"+str(money),fg = "black")
  Products.config(text = "Products: "+str(products), fg = "black")



def acumulator():
  global money
  global products
  now = int(e1.get())
  cashier = now * score
  money = money + cashier
  pound.config(text = "Company Balance: £"+str(money))




  products = products - now
  Products.config(text = "Products: "+str(products))

  omz.config(text = "You can sell " + str(products - 100) + " products presently", bg = "grey")
  if products < 100:
    win.destroy()
    win3 = Tk()
    win3.title("Become a Trillionaire")
    win3.attributes("-fullscreen", True)
    ag3 = Label(win3, text = "Unfortunately, you fell bellow the assets needed to sustain your business...\n Are you willing to try again??")
    ag3.place(relx = 0.12, rely = 0.3)
    win3.mainloop()








def sell():
  A.destroy()
  time.sleep(0.3)
  B.destroy()
  time.sleep(0.03)
  C.destroy()
  time.sleep(0.03)
  D.destroy()

  global CostL1
  global Quest1
  global omz

  CostL1 = Label(win, text = "The current market value is [approx]: £" + str(score), bg = "grey")
  CostL1.place(relx = 0.07, rely = 0.40)

  Quest1 = Label(win, text = "How much do you want to sell: ", bg = "grey")
  Quest1.place(relx = 0.07, rely = 0.54)

  global e1
  e1 = Entry(win)
  e1.place(relx = 0.07, rely = 0.82, relheight = 0.075, relwidth = 0.165)

  omz = Label(win, text = "You can sell " + str(products - 100) + " products presently", bg = "grey")
  omz.place(relx = 0.07, rely = 0.67)

  global Enterz
  Enterz = Button(win, text = "Enter", fg = "darkblue", bg = "#989898", activebackground = "#505050", command = acumulator)
  Enterz.place(relx = 0.26, rely = 0.82, relheight = 0.075, relwidth = 0.15)
  global Backz
  global Chs


  Backz = Button(win, text = "⇦", font = "Bold",fg = "darkblue",bg = "#989898", activebackground = "#505050", command = redot)
  Backz.place(relx = 0.07, rely = 0.26, relheight = 0.08, relwidth = 0.08)

  Chs.config(text = "[press to go back]", fg = "darkblue")
  Chs.place(relx = 0.17, rely = 0.275)













  
def acalculate():
  global money
  global products
  now = int(e.get())
  cashier = now * 1000
  money = money - cashier
  pound.config(text = "Company Balance: £"+str(money))

  products = products + now
  Products.config(text = "Products: "+str(products))
  omr.config(text  = "You can manufacture "+ str((money - 10000)//1000 ) + " products presently", bg = "grey")

 

  if money < 10000:
    win.destroy()
    win2 = Tk()
    win2.title("Become a Trillionaire")
    win2.attributes("-fullscreen", True)
    ag = Label(win2, text = "Unfortunately, you fell bellow the amount needed to sustain your business...\n Are you willing to try again??")
    ag.place(relx = 0.12, rely = 0.3)
    win2.mainloop()
    
 








def redo():
  CostL.destroy()
  Enter.destroy()
  e.destroy()
  Back.destroy()
  Chs.destroy()
  Quest.destroy()
  omr.destroy()
  pound.destroy()
  Products.destroy()
  next()
  pound.config(text = "Company Balance: £"+str(money),fg = "black")
  Products.config(text = "Products: "+str(products), fg = "black")




def make():
  A.destroy()
  time.sleep(0.3)
  B.destroy()
  time.sleep(0.03)
  C.destroy()
  time.sleep(0.03)
  D.destroy()
  global CostL
  global Quest

  CostL = Label(win, text = "The cost of production is --> £" + str(cost), bg = "grey")
  CostL.place(relx = 0.07, rely = 0.40)

  Quest = Label(win, text = "How much do you want to make: ", bg = "grey")
  Quest.place(relx = 0.07, rely = 0.55)

  global e
  e = Entry(win)
  e.place(relx = 0.07, rely = 0.8, relheight = 0.075, relwidth = 0.165)

  global Enter
  Enter = Button(win, text = "Enter", fg = "#66023C", bg = "#989898", activebackground = "#505050", command = acalculate)
  Enter.place(relx = 0.26, rely = 0.8, relheight = 0.075, relwidth = 0.15)
  global Back
  global Chs
  global omr

  omr = Label(win, text  = "You can manufacture "+ str((money - 10000)//1000 ) + " products presently", bg = "grey")
  omr.place(relx = 0.07, rely = 0.67)

  Back = Button(win, text = "⇦", font = "Bold", command = redo, fg = "#66023C", bg = "#989898", activebackground = "#505050")
  Back.place(relx = 0.07, rely = 0.26, relheight = 0.08, relwidth = 0.08)

  Chs.config(text = "[press to go back]", fg = "#66023C")
  Chs.place(relx = 0.17, rely = 0.275)









def next():
  global A
  global B
  global C
  global D
  global Chs
  global pound
  global Products
  late900.destroy()
  start.destroy()
  laterz.destroy()
  laters.destroy()
  late.destroy()
  time.sleep(0.45)
  pound = Label(win, text = "Company Balance: £"+str(money), fg = "black", bg = "grey")
  pound.place(relx = 0.045,rely = 0.15)
  Products = Label(win, text = "Products: "+str(products), fg = "black", bg ="grey")
  Products.place(relx = 0.44,rely = 0.15)

  Line = Label(win, text = "-----------------------------------------------------------------------------------------------------------------------------------------------------------", bg ="grey")
  Line.place(relx = 0.02, rely = 0.19)
  if screen_width > 850:
    Line = Label(win, text = "-------------------------------------------------------------------------------------------------------------------------------------------------------------------", bg ="grey")
    Line.place(relx = 0.02, rely = 0.19)

  Manufacturing = Label(win, text = "[Production = £1000] ", fg = "#a40606", bg = "grey")
  Manufacturing.place(relx = 0.714, rely = 0.0688)
  global wrong
  wrong = Label(win, text = "[Min = £10,000]", fg = "#a40606", bg = "grey")
  wrong.place(relx = 0.045, rely = 0.0685)

  pd = Label(win, text = "[Min = 100]", fg = "#a40606", bg = "grey")
  pd.place(relx = 0.44, rely = 0.0688)

  Chs = Label(win, text = "Options/Choices:", bg ="grey")
  Chs.place(relx = 0.05, rely = 0.3)


  A = Button(win, text = "1: Make more products", fg = "#66023C", bg = "#82A3FF",activebackground = "#282828",relief = "solid", command = make)
  A.place(relx = 0.062, rely = 0.4, relwidth = 0.42, relheight = 0.2)

  B = Button(win, text = "2: Sell your products", fg = "darkblue",bg = "#82A3FF",activebackground = "#282828",relief = "solid",command = sell)
  B.place(relx = 0.51, rely = 0.4, relwidth = 0.42, relheight = 0.2)

  C = Button(win, text = "3: Promote your product", fg = "darkgreen", bg = "#82A3FF",activebackground = "#282828", relief = "solid",command = camp)
  C.place(relx = 0.062, rely = 0.68, relwidth = 0.42, relheight = 0.2)
  
  D = Button(win, text = "4: Invest in other products", fg = "#2b1d0e", bg = "#82A3FF",activebackground = "#282828",relief = "solid",command = invest)
  D.place(relx = 0.51, rely = 0.68, relwidth = 0.42, relheight = 0.2)







  def nextt():
      lab = Label(win, text = "Market Value: £"+str(score), fg = "black", bg="grey")

      lab.place(relx = 0.714, rely = 0.15)


  def clock():    
      global score
      global num
      global number1
      global number2
      num = random.randint(number1,number2)
      score = num
      win.after(1100, clock)
      nextt()    
      win.update()
  clock()



 # answer = Entry(win)
 # answer.place(relx = 0.014, rely = 0.50)






  

global start
start = Button(win, text = "Start", command = next, bg = "#51371b", activebackground='#2b1d0e')
start.place(relx = 0.4, rely = 0.82, relwidth = 0.15, relheight = 0.15)
late = Label(win, text = " [ --- Trillionaire Tycoon --- ]", fg = "gold", bg = "grey")
late.place(relx = 0.37, rely = 0.02)

laterz = Label(win, text = " The Aim of the game is simple:\n [Become a trillionaire] \n 4 choices: Make, Sell, Market or Invest", fg = "gold",bg="grey", font ='Serif')
laterz.place(relx = 0.29, rely = 0.2)

laters = Label(win, text = "\n Note: Minimum amount for your company to stay afloat/ sustained: \n [£10000] in cash & \n [100] amount of prouducts available " , fg = "gold", bg = "grey", font =('Serif',12))
laters.place(relx = 0.18, rely = 0.40)

late900  = Label(win, text = "\n { Top tip: Make your market value higher than production cost }", fg = "#2b1d0e", bg = "grey", font ='Serif')
late900.place(relx  = 0.18, rely = 0.65)




win.mainloop()